import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Add from "./pages/Add";
import Edit from "./pages/Edit";

function App() {
  return (
    <Router>
      <Routes>
        <Route exact path="/employee/list" element={<Home />} />
        <Route exact path="/employee/add" element={<Add />} />
        <Route exact path="/employee/edit" element={<Edit />} />
        <Route path="/" element={<Home />} />
      </Routes>
    </Router>
  );
}

export default App;
