import React, {useEffect} from 'react'
import { useState, useMemo } from "react";
import { AgGridReact} from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { Button, Grid } from '@mui/material';
import {useSelector, useDispatch} from 'react-redux';
import {loadUsers, deleteUser} from '../redux/actions';
import {useNavigate} from 'react-router-dom';


function Home() {
  let dispatch = useDispatch();
  let navigate = useNavigate();
  const  data  = useSelector(state => state.data);
  console.log(data.users);
  useEffect(() => {
    dispatch(loadUsers());
  },[])

  const handleDelete = (id) => {
    if(window.confirm('Are you sure you want to delete the user ?')){
      dispatch(deleteUser(id));
    }
  }

  const del = data.users.map((row) => {
    const val = row.id;
    const value = +val;
    console.log(value);
    return value;
  })


  const[rowData,setRowData] = useState(data.users);

  const[columnDefs,setColumnDefs] = useState([
    {headerName:'First Name',field:'first_name'},
    {headerName:'Last Name',field:'last_name'},
    {headerName:'Email',field:'email'},
    {headerName:'Number',field:'number'},
    {headerName:'Action',field:'action',cellRenderer:(params)=><div>
      <Button variant="contained" color="primary" onClick={() => navigate('/employee/edit')}> Edit </Button>
      <Button variant="contained" color="secondary" onClick={() => handleDelete(del)}> Delete </Button>
    </div>}
  ]);

  const defaultColDef= useMemo( ()=>({
    sortable: true,
    filter: true
  }),[]);

  return (
    <div>
      <h2>Employee List</h2>
      <Grid>
        <Button variant="contained" 
        color="primary" 
        onClick={() => navigate('/employee/add')} > Add User</Button>
      </Grid>
    <div className='ag-theme-balham' style={{height:500, maxWidth:1000}}>
      <AgGridReact
      rowData={rowData}
      columnDefs={columnDefs}
      defaultColDef={defaultColDef}
      />
    </div>
    </div>
  )
}

export default Home