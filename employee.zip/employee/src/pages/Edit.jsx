import React, { useState, useEffect} from "react";
import { makeStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";
import { Button } from '@mui/material';
import { useDispatch, useSelector } from "react-redux";
import { updateUser, getSingleUser} from "../redux/actions";
import {useNavigate, useParams} from 'react-router-dom';

const useStyles = makeStyles((theme) => ({
  root: {
    marginTop: 30,
    "& > *": {
      margin: theme.spacing(1),
      width: "25ch",
    },
  },
}));

function Add() {
  const classes = useStyles();
  const [state, setState] = useState({
    first_name: "",
    last_name: "",
    email: "",
    contact: "",
  });
  const[error,setError] = useState("");
  let { id } = useParams();
  const  user  = useSelector(state => state.data);
  console.log('This is from edit page', user);
  let dispatch = useDispatch();
  let navigate = useNavigate();

  const { first_name, last_name, email, contact } = state;

  useEffect(()=>{
    dispatch(getSingleUser(id));
  },[]);

  useEffect(() => {
    if(user){
      setState({...user});
    }
  },[user]);

  const handleInputChange = (e) => {
    let { name, value } = e.target;
    setState({...state,[name]:value});
  }; 

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('update clicked');
    if(!first_name || !last_name || !email || !contact){
      setError("Please enter all input fields");
    } else {
      dispatch(updateUser(state));
      setError("");
    }
  }

  return (
    <div>
      <h2>Edit User</h2>
      <form 
      className={classes.root} 
      noValidate 
      autoComplete="off" 
      onSubmit={handleSubmit}
      >
        <TextField
          id="First Name"
          label="First Name"
          value={first_name}
          type="text"
          onChange={handleInputChange}
        />
        <br />
        <TextField
          id="Last Name"
          label="Last Name"
          value={last_name}
          type="text"
          onChange={handleInputChange}
        />
        <br />
        <TextField
          id="Email"
          label="Email"
          value={email}
          type="email"
          onChange={handleInputChange}
        />
        <br />
        <TextField
          id="Contact"
          label="Contact"
          value={contact}
          type="text"
          onChange={handleInputChange}
        />
        <br />
        <br />
        <Button 
        style={{width: "100px"}}
        variant="contained" 
        color="primary"
        type="submit"
        onSubmit={handleSubmit}
        onClick={() => navigate('/')}
        >
        Update
        </Button>
      </form>
    </div>
  );
}

export default Add;
